<div class="w3-container w3-padding">

    <h3 class="w3-font-bold w3-font-large">Gestor <span class="w3-text-green">Descarte</span></h3>

    <hr>

    <div class="w3-container">

        <div class="w3-row">
            <a href="javascript:void(0)" onclick="openCity(event, 'London');">
                <div class="w3-third  w3-font-large tablink w3-bottombar w3-hover-light-grey w3-padding">Lista descarte</div>
            </a>
            <a href="javascript:void(0)" onclick="openCity(event, 'Paris');">
                <div class="w3-third w3-font-large tablink w3-bottombar w3-hover-light-grey w3-padding">Registrar descarte</div>
            </a>
            <a href="javascript:void(0)" onclick="openCity(event, 'Tokyo');">
                <div class="w3-third  w3-font-large tablink w3-bottombar w3-hover-light-grey w3-padding">Información descarte - detalle descarte</div>
            </a>
        </div>

        <div id="London" class="w3-container city" style="display:none">

            <br><br>

            <table class="w3-table-all">
                <thead>
                    <tr>
                        <th>Lote</th>
                        <th>Producto</th>
                        <th>N°. jabas</th>
                        <th>Peso bruto</th>
                        <th>Peso Neto</th>
                        <th>Promedio</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>0001</td>
                        <td>Mango</td>
                        <td>10</td>
                        <td>200</td>
                        <td>160.5</td>
                        <td>16.05</td>
                    </tr>

                    <tr>
                        <td>0001</td>
                        <td>Mango</td>
                        <td>10</td>
                        <td>200</td>
                        <td>160.5</td>
                        <td>16.05</td>
                    </tr>

                    <tr>
                        <td>0001</td>
                        <td>Mango</td>
                        <td>10</td>
                        <td>200</td>
                        <td>160.5</td>
                        <td>16.05</td>
                    </tr>

                    <tr>
                        <td>0001</td>
                        <td>Mango</td>
                        <td>10</td>
                        <td>200</td>
                        <td>160.5</td>
                        <td>16.05</td>
                    </tr>

                    <tr>
                        <td>0001</td>
                        <td>Mango</td>
                        <td>10</td>
                        <td>200</td>
                        <td>160.5</td>
                        <td>16.05</td>
                    </tr>

                </tbody>
            </table>
        </div>

        <div id="Paris" class="w3-container city" style="display:none">
            <br><br>
            <div class="w3-col l3 w3 third">
                <select name="selLote" id="selLote" class="w3-select">
                    <option selected disabled>Seleccionar lote...</option>
                    <option>0001</option>
                    <option>0002</option>
                    <option>0003</option>
                    <option>0004</option>
                </select>
            </div>

            <div class="w3-row-padding">

                <div class="w3-col l3 m3">
                    <p class="w3-font-large w3-text-grey">Producto</p>
                    <input type="text" class="w3-input w3-border w3-light-grey" readonly>
                </div>

                <div class="w3-col l3 m3">
                    <p class="w3-font-large w3-text-grey">variedad</p>
                    <input type="text" class="w3-input w3-border w3-light-grey" readonly>
                </div>

                <div class="w3-col l3 m3">
                    <p class="w3-font-large w3-text-grey">Tipo Producción</p>
                    <input type="text" class="w3-input w3-border w3-light-grey" readonly>
                </div>

                <div class="w3-col l3 m3">
                    <p class="w3-font-large w3-text-grey">Hoja cosecha</p>
                    <input type="text" class="w3-input w3-border w3-light-grey" readonly>
                </div>

            </div>

            <div class="w3-row-padding">

                <div class="w3-col l3 m3">
                    <p class="w3-font-large w3-text-grey">tipo cosecha</p>
                    <input type="text" class="w3-input w3-border w3-light-grey" readonly>
                </div>

                <div class="w3-col l3 m3">
                    <p class="w3-font-large w3-text-grey">fecha cosecha</p>
                    <input type="text" class="w3-input w3-border w3-light-grey" readonly>
                </div>

                <div class="w3-col l3 m3">
                    <p class="w3-font-large w3-text-grey">fecha recepción</p>
                    <input type="text" class="w3-input w3-border w3-light-grey" readonly>
                </div>

                <div class="w3-col l3 m3">
                    <p class="w3-font-large w3-text-grey">hora ingreso</p>
                    <input type="text" class="w3-input w3-border w3-light-grey" readonly>
                </div>

            </div>

            <div class="w3-row-padding">

                <div class="w3-col l3 m3">
                    <p class="w3-font-large w3-text-grey">Semana</p>
                    <input type="text" class="w3-input w3-border w3-light-grey" readonly>
                </div>

                <div class="w3-col l3 m3">
                    <p class="w3-font-large w3-text-grey">Exportador</p>
                    <input type="text" class="w3-input w3-border w3-light-grey" readonly>
                </div>

                <div class="w3-col l3 m3">
                    <p class="w3-font-large w3-text-grey">Destino</p>
                    <input type="text" class="w3-input w3-border w3-light-grey" readonly>
                </div>

                <div class="w3-col l3 m3">
                    <p class="w3-font-large w3-text-grey">Productor</p>
                    <input type="text" class="w3-input w3-border w3-light-grey" readonly>
                </div>

            </div>

            <div class="w3-row-padding">

                <div class="w3-col l3 m3">
                    <p class="w3-font-large w3-text-grey">Código Global IP</p>
                    <input type="text" class="w3-input w3-border w3-light-grey" readonly>
                </div>

                <div class="w3-col l3 m3">
                    <p class="w3-font-large w3-text-grey">Cert. Rainforest</p>
                    <input type="text" class="w3-input w3-border w3-light-grey" readonly>
                </div>

                <div class="w3-col l3 m3">
                    <p class="w3-font-large w3-text-grey">Cert. Orgánico</p>
                    <input type="text" class="w3-input w3-border w3-light-grey" readonly>
                </div>

                <div class="w3-col l3 m3">
                    <p class="w3-font-large w3-text-grey">N° de jabas Ingreso</p>
                    <input type="text" class="w3-input w3-border w3-light-grey" readonly>
                </div>

            </div>

        </div>

        <div id="Tokyo" class="w3-container city" style="display:none">
            <br>
            <br>
            <div class="w3-row-padding w3-panel">
                <div class="w3-col l6 m6 w3-leftbar w3-border-green">
                    <p class="w3-text-grey w3-container w3-font-large">Información descarte</p>

                    <div class="w3-section">
                        <div class="w3-col l6 m6 w3-container">
                            <p class="w3-text-grey w3-font-large">Total de jabas</p>
                            <input type="text" class="w3-input w3-light-grey">
                        </div>
                        <div class="w3-col l6 m6 w3-container">
                            <p class="w3-text-grey w3-font-large">Total de jabas</p>
                            <input type="text" class="w3-input w3-light-grey">
                        </div>
                    </div>

                    <div class="w3-section">
                        <div class="w3-col l6 m6 w3-container">
                            <p class="w3-text-grey w3-font-large">Peso Neto Total*</p>
                            <input type="text" class="w3-input w3-light-grey">
                        </div>
                        <div class="w3-col l6 m6 w3-container">
                            <p class="w3-text-grey w3-font-large">Promedio Descarte*</p>
                            <input type="text" class="w3-input w3-light-grey">
                        </div>
                    </div>

                </div>
                <div class="w3-col l6 m6">

                    <p class="w3-text-grey w3-container w3-font-large">Información descarte</p>

                    <div class="w3-section">
                        <div class="w3-col l6 m6 w3-container">
                            <p class="w3-text-grey w3-font-large">Total de jabas</p>
                            <input type="text" class="w3-input w3-light-grey">
                        </div>
                        <div class="w3-col l6 m6 w3-container">
                            <p class="w3-text-grey w3-font-large">Total de jabas</p>
                            <input type="text" class="w3-input w3-light-grey">
                        </div>
                    </div>

                    <div class="w3-section">
                        <div class="w3-col l3 m3 w3-container">
                            <p class="w3-text-grey w3-font-large">Peso Neto Total*</p>
                            <input type="text" class="w3-input w3-light-grey">
                        </div>
                        <div class="w3-col l3 m3 w3-container">
                            <p class="w3-text-grey w3-font-large">Promedio Descarte*</p>
                            <input type="text" class="w3-input w3-light-grey">
                        </div>
                        <div class="w3-col l3 m3 w3-container">

                            <p class="w3-padding-48">
                                <button class="w3-btn w3-round w3-green w3-tiny"><i class="fa fa-plus"></i></button>
                                <button class="w3-btn w3-round w3-dark-grey w3-tiny"><i class="fa fa-trash"></i></button>
                            </p>

                            <br>

                        </div>

                    </div>

                    <table class="w3-table-all">
                        <thead>
                            <tr class="w3-theme-l5">
                                <th>Jabas Descarte</th>
                                <th>Peso Bruto</th>
                                <th>Peso Jaba</th>
                                <th>Peso Tarima</th>
                                <th>Peso Neto</th>
                                <th>Peso Prom.</th>
                                <th><i class="fa fa-caret-square-o-down"></i></th>
                            </tr>
                        </thead>
                    </table>

                    <hr>

                </div>



                <p class="w3-right w3-quarter">
                    <button class="w3-btn w3-round w3-theme-d5 w3-block w3-tiny">Registrar</button>
                </p>
            </div>
        </div>

    </div>

</div>
<script src="view/js/calibrado.js"></script>