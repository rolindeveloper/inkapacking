<div class="w3-bar w3-border w3-light-grey">

    <a href="inicio" class="w3-bar-item w3-button w3-border-right w3-mobile w3-green">Inicio</a>

    <div class="w3-dropdown-hover">

        <button class="w3-button w3-border-right w3-mobile">Recepción <i class="fa fa-filter"></i></button>
        <div class="w3-dropdown-content w3-bar-block w3-card-4">
            <a href="nueva-recepcion" class="w3-bar-item w3-button">Nueva Recepción</a>
            <a href="lista-recepcion" class="w3-bar-item w3-button">Lista Recepción</a>
            <a href="campanas" class="w3-bar-item w3-button">Campañas</a>
            <a href="campanas" class="w3-bar-item w3-button">Reportes</a>
        </div>

    </div>

    <div class="w3-dropdown-hover">
        <button class="w3-button w3-border-right w3-mobile">Calibrado <i class="fa fa-sliders"></i></button>
        <div class="w3-dropdown-content w3-bar-block w3-card-4">
            <a href="nuevo-calibrado" class="w3-bar-item w3-button">Nuevo Calibrado</a>
            <a href="lista-calibrado" class="w3-bar-item w3-button">Lista calibrado</a>
            <a href="descarte" class="w3-bar-item w3-button">Descarte</a>
            <a href="campanas" class="w3-bar-item w3-button">Reportes</a>
        </div>
    </div>

    <div class="w3-dropdown-hover">
        <button class="w3-button w3-border-right w3-mobile">Hidrotérmico <i class="fa fa-server"></i></button>
        <div class="w3-dropdown-content w3-bar-block w3-card-4">
            <a href="nuevo-hidrotermico" class="w3-bar-item w3-button">Nuevo Tratamiento</a>
            <a href="datos-tratamiento" class="w3-bar-item w3-button">Datos tratamiento</a>
            <a href="campanas" class="w3-bar-item w3-button">Reportes</a>
        </div>
    </div>

    <div class="w3-dropdown-hover">
        <button class="w3-button w3-border-right w3-mobile">Empaque <i class="fa fa-cubes"></i></button>
        <div class="w3-dropdown-content w3-bar-block w3-card-4">
            <a href="nuevo-registro-empaque" class="w3-bar-item w3-button">Nuevo registro</a>
            <a href="listado-empaque" class="w3-bar-item w3-button">Listado empaque</a>
        </div>
    </div>

    <div class="w3-dropdown-hover">
        <button class="w3-button w3-border-right w3-mobile">Cámara <i class="fa fa-snowflake-o"></i></button>
        <div class="w3-dropdown-content w3-bar-block w3-card-4">
            <a href="#" class="w3-bar-item w3-button">Nuevo registro</a>
            <a href="#" class="w3-bar-item w3-button">Listado cámara</a>
        </div>
    </div>

    <div class="w3-dropdown-hover">
        <button class="w3-button w3-border-right w3-mobile">Despacho <i class="fa fa-truck"></i></button>
        <div class="w3-dropdown-content w3-bar-block w3-card-4">
            <a href="clientes-registro" class="w3-bar-item w3-button">Nuevo registro</a>
        </div>
    </div>

    <div class="w3-dropdown-hover">
        <button class="w3-button w3-border-right w3-mobile">Personas <i class="fa fa-users"></i></button>
        <div class="w3-dropdown-content w3-bar-block w3-card-4">
            <a href="clientes-registro" class="w3-bar-item w3-button">Supervisor</a>
            <a href="clientes-registro" class="w3-bar-item w3-button">Jefe Cuadrilla</a>
            <a href="clientes-registro" class="w3-bar-item w3-button">Productor</a>
            <a href="clientes-registro" class="w3-bar-item w3-button">Exportador</a>
        </div>
    </div>

    <div class="w3-dropdown-hover">
        <button class="w3-button w3-border-right w3-mobile">Seguridad <i class="fa fa-lock"></i></button>
        <div class="w3-dropdown-content w3-bar-block w3-card-4">
            <a href="clientes-registro" class="w3-bar-item w3-button">Usuarios</a>
            <a href="clientes-registro" class="w3-bar-item w3-button">Perfiles</a>
        </div>
    </div>

</div>