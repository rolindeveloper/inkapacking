<div class="w3-container w3-theme-d5">

    <h1 style="text-transform: uppercase;">inka <b><span class="w3-text-yellow">packing</span></b></h1>

</div>