<div class="w3-container w3-padding">

    <h3 class="w3-font-bold w3-font-large">Listado <span class="w3-text-green">tratamiento hidrotérmico</span></h3>

    <hr>

    <div class="w3-container">

    </div>

</div>
