<div class="w3-container w3-padding">

    <h3 class="w3-font-bold w3-font-large">Registro <span class="w3-text-green">recepción</span></h3>

    <hr>

    <div class="w3-container">

        <form method="post">

            <div class="w3-row-padding">

                <div class="w3-col l4 m4 s4">

                    <p>
                        
                    <label for="lote" class="w3-text-grey w3-font-large">Producto</label></p>

                    <select name="producto" id="producto" class="w3-select">

                        <option>Seleccione...</option>

                        <option value="Mango">Mango</option>

                        <option value="Palta">Palta</option>

                    </select>

                </div>

                <div class="w3-col l4 m4 s4">

                    <p><label for="lote" class="w3-text-grey w3-font-large">Fecha Cosecha</label></p>

                    <input type="date" class="w3-input">

                </div>

                <div class="w3-col l4 m4 s4">

                    <p><label for="lote" class="w3-text-grey w3-font-large">lote</label></p>

                    <input type="numer" class="w3-input w3-light-grey" id="numero-lote" readonly>

                </div>

            </div>

            <div class="w3-row-padding">

                <div class="w3-col l3 m3 s3">
                    <p>
                        <label for="variedad" class="w3-text-grey w3-font-large">Variedad</label>
                        <button type="button" onclick="document.getElementById('modalVariedad').style.display='block'" class="w3-btn w3-tiny w3-green w3-round-xlarge">+</button>
                    </p>

                    <select name="producto" id="producto" class="w3-select">

                        <option value="Mango">Hadden</option>

                        <option value="Palta">Edwars</option>

                    </select>

                </div>

                <div class="w3-col l3 m3 s3">
                    <p>
                        <label for="variedad" class="w3-text-grey w3-font-large">Tipo producción</label>
                        <button type="button" onclick="document.getElementById('modalProduccion').style.display='block'" class="w3-btn w3-tiny w3-green w3-round-xlarge">+</button>
                    </p>

                    <select name="producto" id="producto" class="w3-select">

                        <option value="Convencional">Convencional</option>

                        <option value="Orgánico">Orgánico</option>

                    </select>

                </div>

                <div class="w3-col l3 m3 s3">
                    <p>
                        <label for="variedad" class="w3-text-grey w3-font-large">Tipo cosecha</label>
                        <button type="button" onclick="document.getElementById('modalCosecha').style.display='block'" class="w3-btn w3-tiny w3-green w3-round-xlarge">+</button>
                    </p>

                    <select name="producto" id="producto" class="w3-select">

                        <option value="Convencional">Propia</option>

                    </select>

                </div>

                <div class="w3-col l3 m3 s3">
                    <p>

                        <label for="variedad" class="w3-text-grey w3-font-large">Supervisor Campo</label>
                    </p>

                    <select name="producto" id="producto" class="w3-select">

                        <option value="Convencional">juan perez</option>

                    </select>

                </div>

            </div>

            <div class="w3-row-padding">

                <div class="w3-col m3 l3 s3">

                    <p>
                        <label for="variedad" class="w3-text-grey w3-font-large">Seleccione Destino</label>
                    </p>

                    <select name="producto" id="producto" class="w3-select">

                        <option value="USA">USA</option>
                        <option value="COREA">COREA</option>
                        <option value="JAPÓN">JAPÓN</option>
                        <option value="CHINA">CHINA</option>
                        <option value="CHILE">CHILE</option>
                        <option value="NUEVA ZELANDA">NUEVA ZELANDA</option>
                        <option value="MÉXICO">MÉXICO</option>

                    </select>

                </div>

                <div class="w3-col m3 l3 s3">
                    <p>
                        <label for="variedad" class="w3-text-grey w3-font-large">Fecha ingreso</label>
                    </p>

                    <input type="text" class="w3-input w3-light-grey" value="2024-09-09">
                </div>

                <div class="w3-col m3 l3 s3">

                    <p>
                        <label for="variedad" class="w3-text-grey w3-font-large">Hora ingreso</label>
                    </p>

                    <input type="time" class="w3-input w3-light-grey" value="13:30">
                </div>

                <div class="w3-col m3 l3 s3">

                    <p>
                        <label for="variedad" class="w3-text-grey w3-font-large">Semana</label>
                    </p>

                    <input type="number" class="w3-input w3-light-grey" value="1">
                </div>

            </div>

            <div class="w3-row-padding">

                <div class="w3-col m6 l6 s6">
                    <p>
                        <label class="w3-text-grey w3-font-large" for="jefeCaudrilla">Jefe de Caudrilla <i class="fa fa-th"></i></label>
                    </p>

                    <select name="producto" id="producto" class="w3-select w3-half">
                        <option selected disabled>Seleccione</option>
                        <option value="usuario">usuario</option>
                    </select>

                </div>

                <div class="w3-col m6 l6 s6">
                    <p>
                        <label class="w3-text-grey w3-font-large" for="jefeCaudrilla">Hoja cosecha <i class="fa fa-file"></i></label>
                    </p>

                    <input type="text" class="w3-input w3-half">

                </div>

            </div>

            <hr>

            <div class="w3-row-padding">

                <div class="w3-col m3 s3 l3 w3-border w3-margin w3-round">

                    <p class="w3-font-large w3-text-grey">información del productor</p>

                    <hr>

                    <b class="w3-text-grey"><i>Productor(*)</i></b>

                    <select name="selProductor" class="w3-select js-example-basic-single w3-border-grey" id="selProductor">

                        <option selected disabled"></option>

                    </select>

                    <p class="w3-font-large w3-text-grey">
                        Código LP*
                    </p>

                    <input type="text" class="w3-input w3-light-grey">

                    <p class="w3-font-large w3-text-grey">Cert. Global/Rainforest*</p>

                    <input type="text" class="w3-input w3-light-grey">

                    <p class="w3-text-grey w3-font-large">Cert./Orgánico*</p>

                    <input type="text" class="w3-input w3-light-grey">

                    <br>

                </div>

                <div class="w3-col m3 s3 l3 w3-border w3-margin w3-round">

                    <p class="w3-font-large w3-text-grey">información del exportador</p>

                    <hr>

                    <p class="w3-text-grey w3-font-large">Exportador*</p>

                    <select name="selProductor" class="w3-select js-example-basic-single w3-border-grey" id="selProductor">

                        <option selected disabled"></option>

                    </select>

                    <p class="w3-text-grey w3-font-large">Código exportador*</p>

                    <input type="text" class="w3-input w3-light-grey">

                    <p class="w3-text-grey w3-font-large">Siglas exportador*</p>

                    <input type="text" class="w3-input w3-light-grey">

                    <br>

                </div>

                <div class="w3-col m3 s3 l3 w3-border w3-margin w3-round">

                    <p class="w3-font-large w3-text-grey">información del transporte.</p>

                    <hr>

                    <p class="w3-text-grey w3-font-large">Guía remisión*</p>

                    <input type="text" class="w3-input w3-light-grey">

                    <p class="w3-text-grey w3-font-large">Adjuntar Guía remisión*</p>

                    <input type="file" class="w3-input w3-border">

                    <p class="w3-text-grey w3-font-large">Adjuntar MDT*</p>

                    <input type="file" class="w3-input w3-border">

                    <p class="w3-text-grey w3-font-large">Placa trasnporte*</p>

                    <input type="text" class="w3-input w3-border">

                    <br>

                </div>

            </div>

            <hr>

            <div class="w3-row-padding">

                <div class="w3-col m6 l6 s6">

                    <p class="w3-font-large w3-text-grey">Información de jabas</p>
                    <hr>

                    <div class="w3-col m6 l6 w3-container">

                        <p>
                            <label for="" class="w3-text-grey w3-font-large">N° Jabas campo*</label>
                        </p>

                        <input type="number" class="w3-input w3-border">

                        <p>
                            <label for="" class="w3-text-grey w3-font-large">Promedio Jabas campo*</label>
                        </p>

                        <input type="number" class="w3-input w3-border">

                        <p>
                            <label for="" class="w3-text-grey w3-font-large">Peso neto ingreso *</label>
                        </p>

                        <input type="number" class="w3-input w3-border">

                        <p>
                            <label for="" class="w3-text-grey w3-font-large">Peso bruto ingreso *</label>
                        </p>

                        <input type="number" class="w3-input w3-border">

                        <p>
                            <label for="" class="w3-text-grey w3-font-large">Diferencia peso *</label>
                        </p>

                        <input type="number" class="w3-input w3-border">

                        <p>
                            <label for="" class="w3-text-grey w3-font-large">estado</label>

                        </p>

                        <select name="selEstado" id="" class="w3-select w3-border">

                            <option value="Recepcionado">Recepcionado</option>

                        </select>

                        <br>
                        <br><br>

                    </div>

                    <div class="w3-col m6 l6 w3-container">

                        <p>
                            <label for="" class="w3-text-grey w3-font-large">Peso kg Campo *</label>
                        </p>

                        <input type="number" class="w3-input w3-border">

                        <p>
                            <label for="" class="w3-text-grey w3-font-large">N° Jabas Ingreso *</label>
                        </p>

                        <input type="number" class="w3-input w3-border">

                        <p>
                            <label for="" class="w3-text-grey w3-font-large">Kg.Prom.Jaba Ingreso*</label>
                        </p>

                        <input type="number" class="w3-input w3-border">

                        <p>
                            <label for="" class="w3-text-grey w3-font-large">Diferencia Jabas *</label>
                        </p>

                        <input type="number" class="w3-input w3-border">

                        <p>
                            <label for="" class="w3-text-grey w3-font-large">Tipo Servicio*</label>
                        </p>

                        <select name="tipoServicio" class="w3-select w3-border" id="tipoServicio">
                            <option value="Hidro y Proceso">Hidro y Proceso</option>
                        </select>

                        <p>
                            <label for="" class="w3-text-grey w3-font-large">Observaciones</label>
                        </p>

                        <textarea name="" class="w3-input w3-border" id="" placeholder="Ingresa una observación"></textarea>

                    </div>

                </div>

                <div class="w3-col m6 l6 s6">

                    <p class="w3-font-large w3-text-grey">Detalles recepción</p>

                    <hr>

                    <div class="w3-col m4 l4 s4 w3-container">

                        <p>
                            <label for="" class="w3-text-grey">Peso Stocker *</label>
                        </p>

                        <input type="number" class="w3-input w3-border" value="0">

                    </div>

                    <div class="w3-col m4 l4 s4 w3-container">

                        <p>
                            <label for="" class="w3-text-grey">Peso Tarima *</label>
                        </p>

                        <input type="number" class="w3-input w3-border" value="23">

                    </div>

                    <div class="w3-col m4 l4 s4 w3-container">

                        <p>
                            <label for="" class="w3-text-grey">Destare jaba *</label>
                        </p>

                        <input type="number" class="w3-input w3-border" value="1.8">

                    </div>

                    <div class="w3-col m4 l4 s4 w3-container">

                        <p>
                            <label for="" class="w3-text-grey">N° jabas *</label>
                        </p>

                        <input type="number" class="w3-input w3-border" value="1.8">

                    </div>

                    <div class="w3-col m4 l4 s4 w3-container">

                        <p>
                            <label for="" class="w3-text-grey">Peso bruto *</label>
                        </p>

                        <input type="number" class="w3-input w3-border" value="1.8">

                    </div>

                    <div class="w3-col m4 l4 s4 w3-container">
                        <br><br>
                        <button class="w3-btn w3-round-large w3-small w3-theme-d5"><i class="fa fa-plus"></i></button>
                        <button class="w3-btn w3-round-large w3-small w3-red"><i class="fa fa-trash"></i></button>

                    </div>

                    <div class="w3-col w3-container w3-padding">

                        <table class="w3-table-all">
                            <thead>
                                <tr class="w3-theme-l5">
                                    <th>Peso Bruto</th>
                                    <th>Cant. Jabas</th>
                                    <th>Dest. Jabas</th>
                                    <th>Peso tarima</th>
                                    <th>Peso stocker</th>
                                    <th>Peso Neto</th>
                                    <th>Peso Prom.</th>
                                    <th><i class="fa fa-cog"></i></th>
                                </tr>
                            </thead>
                        </table>

                    </div>

                </div>

            </div>

            <div class="w3-row-padding">
                <div class="w3-container w3-right">
                    <a href="inicio" class="w3-btn w3-round w3-small w3-red">Cancelar</a>

                    <button type="submit" class="w3-btn w3-round w3-small w3-theme-d5">Guardar <i class="fa fa-save"></i></button>
                </div>
            </div>

        </form>

    </div>

</div>

<div id="modalVariedad" class="w3-modal">

  <div class="w3-modal-content w3-animate-opacity" style="width: 500px;">

    <header class="w3-container w3-theme-d5">

      <span onclick="document.getElementById('modalVariedad').style.display='none'"
        class="w3-button w3-display-topright">&times;</span>

      <h5 class="w3-font-large">registrar variedad</h5>
    </header>

    <form method="post" id="formulario">
      
      <div class="w3-row-padding">
        <div class="w3-col">
            <p>
                <label for="nombreVariedad" class="w3-font-large w3-text-grey">Nombre variedad</label>
            </p>
            <input type="text" class="w3-input" required>

            <p>
                <label for="nombreVariedad" class="w3-font-large w3-text-grey">Nombre variedad</label>
            </p>

            <select name="producto" id="producto" class="w3-select">
                <option selected disabled>Seleccione...</option>
                <option value="Mango">Mango</option>
                <option value="Palta">Palta</option>
            </select>
        </div>
      </div>

      <footer class="w3-container">
        <hr>
        <p>
          <button type="button" class="w3-btn w3-round w3-small w3-red" onclick="document.getElementById('modalVariedad').style.display='none'">
            Cerrar
          </button>

          <button type="submit" class="w3-btn w3-round w3-small w3-green w3-right btnSuspencion">
            Guardar <i class="fa fa-save"></i>
          </button>
        </p>
      </footer>
    </form>

  </div>

</div>

<div id="modalProduccion" class="w3-modal">
    
  <div class="w3-modal-content w3-animate-opacity" style="width: 500px;">

    <header class="w3-container w3-theme-d5">

      <span onclick="document.getElementById('modalProduccion').style.display='none'"
        class="w3-button w3-display-topright">&times;</span>

      <h5 class="w3-font-large">registrar tipo producción</h5>

    </header>

    <form method="post" id="formulario">
      
      <div class="w3-row-padding">

        <div class="w3-col">
            <p>
                <label for="nombreVariedad" class="w3-font-large w3-text-grey">Nombre variedad</label>
            </p>

            <input type="text" class="w3-input" required>

        </div>

      </div>

      <footer class="w3-container">

        <p>

          <button type="button" class="w3-btn w3-round w3-small w3-red" onclick="document.getElementById('modalProduccion').style.display='none'">
            Cerrar
          </button>

          <button type="submit" class="w3-btn w3-round w3-small w3-green w3-right btnSuspencion">

            Guardar <i class="fa fa-save"></i>

          </button>

        </p>

      </footer>

    </form>

  </div>

</div>

<div id="modalCosecha" class="w3-modal">
    
  <div class="w3-modal-content w3-animate-opacity" style="width: 500px;">

    <header class="w3-container w3-theme-d5">

      <span onclick="document.getElementById('modalcosecha').style.display='none'"
        class="w3-button w3-display-topright">&times;</span>

      <h5 class="w3-font-large">registrar tipo cosecha</h5>

    </header>

    <form method="post" id="formulario">
      
      <div class="w3-row-padding">

        <div class="w3-col">
            <p>
                <label for="nombreVariedad" class="w3-font-large w3-text-grey">Tipo cosecha</label>
            </p>

            <input type="text" class="w3-input" required>

        </div>

      </div>

      <footer class="w3-container">

        <p>

          <button type="button" class="w3-btn w3-round w3-small w3-red" onclick="document.getElementById('modalCosecha').style.display='none'">
            Cerrar
          </button>

          <button type="submit" class="w3-btn w3-round w3-small w3-green w3-right btnSuspencion">

            Guardar <i class="fa fa-save"></i>

          </button>

        </p>

      </footer>

    </form>

  </div>

</div>

<script>
    $(document).ready(function() {
    $('.js-example-basic-single').select2();
})
</script>

<script src="view/js/nueva-recepcion.js"></script>