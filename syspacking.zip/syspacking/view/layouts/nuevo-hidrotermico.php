<div class="w3-container w3-padding">

    <h3 class="w3-font-bold w3-font-large">nuevo <span class="w3-text-green">tratamiento hidrotérmico</span></h3>

    <hr>

    <div class="w3-container">

        <div class="w3-section">

            <div class="w3-row-padding">

                <div class="w3-col l3">
                    
                    <p class="w3-font-large w3-text-greys">
                        Fecha
                    </p>

                    <input type="date" class="w3-input w3-border" name="fecha" id="fecha">

                </div>

                <div class="w3-col l3">

                    <p class="w3-font-large w3-text-greys">
                        N° CANASTA
                    </p>

                    <input type="number" class="w3-input w3-border">

                </div>

                <div class="w3-col l3">

                    <p class="w3-font-large w3-text-greys">
                        N°
                    </p>

                    <input type="number" class="w3-input w3-border">

                </div>

                <div class="w3-col l3">

                    <p class="w3-font-large w3-text-greys">
                        hora inicio
                    </p>

                    <input type="time" class="w3-input w3-border">

                </div>

            </div>

            <div class="w3-row-padding">

                <div class="w3-col l3">
                    
                    <p class="w3-font-large w3-text-greys">
                        TEMPERATURA
                    </p>

                    <input type="number" class="w3-input w3-border" name="fecha" id="fecha">

                </div>

                <div class="w3-col l3">

                    <p class="w3-font-large w3-text-greys">
                        N° tanque
                    </p>

                    <select name="selNTanque" id="selNTanque" class="w3-select w3-border">
                        <option value="1">Tanque 1</option>
                        <option value="2">Tanque 2</option>
                        <option value="3">Tanque 3</option>
                        <option value="4">Tanque 4</option>
                        <option value="5">Tanque 5</option>
                        <option value="6">Tanque 6</option>
                    </select>

                </div>

                <div class="w3-col l3">
                    <p class="w3-text-grey w3-font-large">
                        Destino
                    </p>
                    <select name="selDestino" id="selDestino" class="w3-select w3-border">
                        <option value="USA">USA</option>
                        <option value="EUROPA">EUROPA</option>
                        <option value="CHILE">CHILE</option>
                        <option value="JAPÓN">JAPÓN</option>
                        <option value="COREA">COREA</option>
                        <option value="NUEVA ZELANDA">NUEVA ZELANDA</option>
                    </select>
                </div>

            </div>

            <hr>

            <div class="w3-row-padding">
                <div class="w3-col l6">
                    <p class="w3-text-grey w3-font-large">
                        Tarima
                    </p>
                    <select name="selDestino" id="selDestino" class="w3-select w3-third">
                        <?php

                            $i = 1;
                            while(10>$i){
                               echo '<option>'.$i++.'</option>';
                            }

                        ?>
                    </select>
                </div>
            </div>
            
            <div class="w3-row-padding w3-section">
                <div class="w3-col">
                    <span class="w3-font-large w3-text-grey">TARIMAS: </span>
                    <button class="w3-button w3-light-grey w3-round w3-xxlarge">010</button>
                    <button class="w3-button w3-light-grey w3-round w3-xxlarge">067</button>
                    <button class="w3-button w3-light-grey w3-round w3-xxlarge">012</button>

                    <button class="w3-button w3-light-grey w3-round w3-xxlarge">011</button>
                    <button class="w3-button w3-light-grey w3-round w3-xxlarge">021</button>
                    <button class="w3-button w3-light-grey w3-round w3-xxlarge">028</button>
                    <button class="w3-button w3-light-grey w3-round w3-xxlarge">090</button>
                </div>
            </div>

            <hr>

            <div class="w3-row-padding">
                
                <p class="w3-font-large w3-text-grey">
                    proceso de encanastillado
                </p>

                <div class="w3-container">
                    
                </div>

                <table class="w3-table-all w3-tiny">

                    <thead>

                        <tr>

                            <th></th>

                            <th>A</th>

                            <th>B</th>

                            <th>C</th>

                            <th>D</th>

                            <th>E</th>

                            <th>F</th>

                        </tr>

                    </thead>

                    <tbody>

                        <tr class="w3-theme-l5">

                            <td>N°</td>

                            <td>

                                <select class="w3-select w3-border" style="max-width: 70px;" name="" id="">
                                    <option value="10001">10001</option>
                                    <option value="10002">10002</option>
                                    <option value="10003">10003</option>
                                    <option value="10004">10004</option>
                                    <option value="10005">10005</option>
                                    <option value="10006">10006</option>
                                    <option value="10007">10007</option>
                                    <option value="10008">10008</option>
                                    <option value="10009">10009</option>
                                </select>

                                <select class="w3-select w3-border" style="max-width: 40px;" name="" id="">
                                    <option value="C4">C4</option>
                                    <option value="C6">C6</option>
                                    <option value="C8">C8</option>
                                    <option value="C10">C10</option>
                                    <option value="C12">C12</option>
                                    <option value="C14">C14</option>
                                </select>

                                <span class="w3-tiny w3-text-grey">vacío</span>
                                <input type="checkbox" class="w3-check">        

                            </td>

                            <td>

                                <select class="w3-select w3-border" style="max-width: 70px;" name="" id="">
                                    <option value="10001">10001</option>
                                    <option value="10002">10002</option>
                                    <option value="10003">10003</option>
                                    <option value="10004">10004</option>
                                    <option value="10005">10005</option>
                                    <option value="10006">10006</option>
                                    <option value="10007">10007</option>
                                    <option value="10008">10008</option>
                                    <option value="10009">10009</option>
                                </select>

                                <select class="w3-select w3-border" style="max-width: 40px;" name="" id="">
                                    <option value="C4">C4</option>
                                    <option value="C6">C6</option>
                                    <option value="C8">C8</option>
                                    <option value="C10">C10</option>
                                    <option value="C12">C12</option>
                                    <option value="C14">C14</option>
                                </select>

                                <span class="w3-tiny w3-text-grey">vacío</span>
                                <input type="checkbox" class="w3-check">        

                            </td>

                            <td>

                                <select class="w3-select w3-border" style="max-width: 60px;" name="" id="">
                                    <option value="10001">10001</option>
                                    <option value="10002">10002</option>
                                    <option value="10003">10003</option>
                                    <option value="10004">10004</option>
                                    <option value="10005">10005</option>
                                    <option value="10006">10006</option>
                                    <option value="10007">10007</option>
                                    <option value="10008">10008</option>
                                    <option value="10009">10009</option>
                                </select>

                                <select class="w3-select w3-border" style="max-width: 40px;" name="" id="">
                                    <option value="C4">C4</option>
                                    <option value="C6">C6</option>
                                    <option value="C8">C8</option>
                                    <option value="C10">C10</option>
                                    <option value="C12">C12</option>
                                    <option value="C14">C14</option>
                                </select>

                                <span class="w3-tiny w3-text-grey">vacío</span>
                                <input type="checkbox" class="w3-check">        

                            </td>

                            <td>

                                <select class="w3-select w3-border" style="max-width: 70px;" name="" id="">
                                    <option value="10001">10001</option>
                                    <option value="10002">10002</option>
                                    <option value="10003">10003</option>
                                    <option value="10004">10004</option>
                                    <option value="10005">10005</option>
                                    <option value="10006">10006</option>
                                    <option value="10007">10007</option>
                                    <option value="10008">10008</option>
                                    <option value="10009">10009</option>
                                </select>

                                <select class="w3-select w3-border" style="max-width: 40px;"name="" id="">
                                    <option value="C4">C4</option>
                                    <option value="C6">C6</option>
                                    <option value="C8">C8</option>
                                    <option value="C10">C10</option>
                                    <option value="C12">C12</option>
                                    <option value="C14">C14</option>
                                </select>

                                <span class="w3-tiny w3-text-grey">vacío</span>
                                <input type="checkbox" class="w3-check">        

                            </td>

                            <td>

                                <select class="w3-select w3-border" style="max-width: 70px;" name="" id="">
                                    <option value="10001">10001</option>
                                    <option value="10002">10002</option>
                                    <option value="10003">10003</option>
                                    <option value="10004">10004</option>
                                    <option value="10005">10005</option>
                                    <option value="10006">10006</option>
                                    <option value="10007">10007</option>
                                    <option value="10008">10008</option>
                                    <option value="10009">10009</option>
                                </select>

                                <select class="w3-select w3-border" style="max-width: 40px;" name="" id="">
                                    <option value="C4">C4</option>
                                    <option value="C6">C6</option>
                                    <option value="C8">C8</option>
                                    <option value="C10">C10</option>
                                    <option value="C12">C12</option>
                                    <option value="C14">C14</option>
                                </select>

                                <span class="w3-tiny w3-text-grey">vacío</span>
                                <input type="checkbox" class="w3-check">        

                            </td>

                            <td>

                                <select class="w3-select w3-border" style="max-width: 70px;" name="" id="">
                                    <option value="10001">10001</option>
                                    <option value="10002">10002</option>
                                    <option value="10003">10003</option>
                                    <option value="10004">10004</option>
                                    <option value="10005">10005</option>
                                    <option value="10006">10006</option>
                                    <option value="10007">10007</option>
                                    <option value="10008">10008</option>
                                    <option value="10009">10009</option>
                                </select>

                                <select class="w3-select w3-border" style="max-width: 40px;" name="" id="">
                                    <option value="C4">C4</option>
                                    <option value="C6">C6</option>
                                    <option value="C8">C8</option>
                                    <option value="C10">C10</option>
                                    <option value="C12">C12</option>
                                    <option value="C14">C14</option>
                                </select>

                                <span class="w3-tiny w3-text-grey">vacío</span>
                                <input type="checkbox" class="w3-check">        

                            </td>

                        </tr>

                        <?php
                            for ($i=0; $i < 5; $i++) { 
                               echo ' <tr>

                            <td>N°</td>

                            <td>

                                <select class="w3-select w3-border" style="max-width: 70px;" name="" id="">
                                    <option value="10001">10001</option>
                                    <option value="10002">10002</option>
                                    <option value="10003">10003</option>
                                    <option value="10004">10004</option>
                                    <option value="10005">10005</option>
                                    <option value="10006">10006</option>
                                    <option value="10007">10007</option>
                                    <option value="10008">10008</option>
                                    <option value="10009">10009</option>
                                </select>

                                <select class="w3-select w3-border" style="max-width: 40px;" name="" id="">
                                    <option value="C4">C4</option>
                                    <option value="C6">C6</option>
                                    <option value="C8">C8</option>
                                    <option value="C10">C10</option>
                                    <option value="C12">C12</option>
                                    <option value="C14">C14</option>
                                </select>

                                <span class="w3-tiny w3-text-grey">vacío</span>
                                <input type="checkbox" class="w3-check">
                                

                            </td>

                            <td>

                                <select class="w3-select w3-border" style="max-width: 70px;" name="" id="">
                                    <option value="10001">10001</option>
                                    <option value="10002">10002</option>
                                    <option value="10003">10003</option>
                                    <option value="10004">10004</option>
                                    <option value="10005">10005</option>
                                    <option value="10006">10006</option>
                                    <option value="10007">10007</option>
                                    <option value="10008">10008</option>
                                    <option value="10009">10009</option>
                                </select>

                                <select class="w3-select w3-border" style="max-width: 40px;" name="" id="">
                                    <option value="C4">C4</option>
                                    <option value="C6">C6</option>
                                    <option value="C8">C8</option>
                                    <option value="C10">C10</option>
                                    <option value="C12">C12</option>
                                    <option value="C14">C14</option>
                                </select>

                                <span class="w3-tiny w3-text-grey">vacío</span>
                                <input type="checkbox" class="w3-check">
                                

                            </td>

                            <td>

                                <select class="w3-select w3-border" style="max-width: 60px;" name="" id="">
                                    <option value="10001">10001</option>
                                    <option value="10002">10002</option>
                                    <option value="10003">10003</option>
                                    <option value="10004">10004</option>
                                    <option value="10005">10005</option>
                                    <option value="10006">10006</option>
                                    <option value="10007">10007</option>
                                    <option value="10008">10008</option>
                                    <option value="10009">10009</option>
                                </select>

                                <select class="w3-select w3-border" style="max-width: 40px;" name="" id="">
                                    <option value="C4">C4</option>
                                    <option value="C6">C6</option>
                                    <option value="C8">C8</option>
                                    <option value="C10">C10</option>
                                    <option value="C12">C12</option>
                                    <option value="C14">C14</option>
                                </select>

                                <span class="w3-tiny w3-text-grey">vacío</span>
                                <input type="checkbox" class="w3-check">
                                

                            </td>

                            <td>

                                <select class="w3-select w3-border" style="max-width: 70px;" name="" id="">
                                    <option value="10001">10001</option>
                                    <option value="10002">10002</option>
                                    <option value="10003">10003</option>
                                    <option value="10004">10004</option>
                                    <option value="10005">10005</option>
                                    <option value="10006">10006</option>
                                    <option value="10007">10007</option>
                                    <option value="10008">10008</option>
                                    <option value="10009">10009</option>
                                </select>

                                <select class="w3-select w3-border" style="max-width: 40px;"name="" id="">
                                    <option value="C4">C4</option>
                                    <option value="C6">C6</option>
                                    <option value="C8">C8</option>
                                    <option value="C10">C10</option>
                                    <option value="C12">C12</option>
                                    <option value="C14">C14</option>
                                </select>

                                <span class="w3-tiny w3-text-grey">vacío</span>
                                <input type="checkbox" class="w3-check">
                                

                            </td>

                            <td>

                                <select class="w3-select w3-border" style="max-width: 70px;" name="" id="">
                                    <option value="10001">10001</option>
                                    <option value="10002">10002</option>
                                    <option value="10003">10003</option>
                                    <option value="10004">10004</option>
                                    <option value="10005">10005</option>
                                    <option value="10006">10006</option>
                                    <option value="10007">10007</option>
                                    <option value="10008">10008</option>
                                    <option value="10009">10009</option>
                                </select>

                                <select class="w3-select w3-border" style="max-width: 40px;" name="" id="">
                                    <option value="C4">C4</option>
                                    <option value="C6">C6</option>
                                    <option value="C8">C8</option>
                                    <option value="C10">C10</option>
                                    <option value="C12">C12</option>
                                    <option value="C14">C14</option>
                                </select>

                                <span class="w3-tiny w3-text-grey">vacío</span>
                                <input type="checkbox" class="w3-check">
                                

                            </td>

                            <td>

                                <select class="w3-select w3-border" style="max-width: 70px;" name="" id="">
                                    <option value="10001">10001</option>
                                    <option value="10002">10002</option>
                                    <option value="10003">10003</option>
                                    <option value="10004">10004</option>
                                    <option value="10005">10005</option>
                                    <option value="10006">10006</option>
                                    <option value="10007">10007</option>
                                    <option value="10008">10008</option>
                                    <option value="10009">10009</option>
                                </select>

                                <select class="w3-select w3-border" style="max-width: 40px;" name="" id="">
                                    <option value="C4">C4</option>
                                    <option value="C6">C6</option>
                                    <option value="C8">C8</option>
                                    <option value="C10">C10</option>
                                    <option value="C12">C12</option>
                                    <option value="C14">C14</option>
                                </select>

                                <span class="w3-tiny w3-text-grey">vacío</span>
                                <input type="checkbox" class="w3-check">                               

                            </td>

                        </tr>';
                            }
                        ?>

                    </tbody>

                </table>

            </div>

        </div>

        

    </div>

</div>


<script src="view/js/nueva-recepcion.js"></script>