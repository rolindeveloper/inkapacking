<div class="w3-container w3-padding">

    <h3 class="w3-font-bold w3-font-large">Lista <span class="w3-text-green">calibrado</span></h3>

    <hr>

    <div class="w3-container">

        <div class="w3-section">
            <button class="w3-btn w3-round-large w3-green"><b><i class="fa fa-file-excel-o"></i></b> Exportar</button>
            <button class="w3-btn w3-round-large w3-dark-grey"> <b><i class="fa fa-th"></i></b> control</button>

            <div class="w3-right w3-container">
                <div class="w3-col m6 l6 s6">
                    <input type="date" class="w3-input" id="startDate">
                </div>
                <div class="w3-col m6 l6 s6">
                    <input type="date" class="w3-input" id="endDate">
                </div>
            </div>
        </div>

        <table class="w3-table-all" id="listado-recepcion">
            <thead>
                <tr class="">
                    <th>Lote</th>
                    <th>Campaña</th>
                    <th>Producto</th>
                    <th>variedad</th>
                    <th>Exportador</th>
                    <th>F. Calibración</th>
                    <th>Total Jabas</th>
                    <th>Kg. Neto</th>
                    <th>Jabas Descarte</th>
                    <th>Kg. Descarte</th>
                    <th>Prom.Jaba Calibrado</th>
                    <th><i class="fa fa-caret-square-o-down"></i></th>
                </tr>
            </thead>
            <tbody>

            </tbody>
        </table>

    </div>

</div>


<script src="view/js/nueva-recepcion.js"></script>